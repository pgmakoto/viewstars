using System.Collections.Generic;
using System;
using System.Configuration;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.Intrinsics.Arm;
using System.Runtime.Intrinsics.X86;
using System.Security.Cryptography;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;
using System.Xml.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.DataFormats;
using System.Numerics;
using System.Diagnostics.Eventing.Reader;
using Microsoft.Win32.SafeHandles;
using ucPgmac;


namespace bsc5
{
    public partial class Form1 : Form
    {

        public double ScopeAltitude = 0;
        public double ScopeAzimuth = 0;

        double viewAzmith = 0;
        double viewAltitude = 0;
        public Cel cel = new Cel();

        List<Star> stars = new List<Star>();

        HipStar hip;

        string datafile = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "") folderBrowserDialog1.InitialDirectory = AppContext.BaseDirectory;
            if (DialogResult.OK == folderBrowserDialog1.ShowDialog())
            {
                textBox1.Text = folderBrowserDialog1.SelectedPath;
                AddUpdateAppSettings("DataPath", textBox1.Text);
            }

            Debug.WriteLine("------------------------------");

            var appSettings = ConfigurationManager.AppSettings;
            foreach (var key in appSettings.AllKeys)
            {
                Debug.WriteLine("Key: {0} Value: {1}", key, appSettings[key]);
                string result = appSettings[key] ?? "Not Found";
                Debug.WriteLine(result);
            }
            Debug.WriteLine("-----ReadAllSettings----------");

            ReadAllSettings();
            Debug.WriteLine("------------------------------");

            ReadSetting("Setting1");
            ReadSetting("NotValid");
            AddUpdateAppSettings("NewSetting", "May 7, 2014");
            AddUpdateAppSettings("Setting1", "May 8, 2014");

            Debug.WriteLine("-----ReadAllSettings----------");

            ReadAllSettings();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tenqu1.cel = cel;

            cel.Latitude = 35.345500117631445;
            cel.Longitude = -137.1579632651267;

            //////////////////////
            if (true)
            {
                //https://dobon.net/vb/dotnet/system/registrykey.html
                //�L�[�iHKEY_CURRENT_USER\Software\test\sub�j���J��
                string name = Application.ProductName;

                #region Registry
                Microsoft.Win32.RegistryKey regkey =
                    Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"Software\" + Application.ProductName + @"\sub");
                //��̃R�[�h�ł́A�w�肵���L�[�����݂��Ȃ��Ƃ��͐V�����쐬�����B
                //�쐬����Ȃ��悤�ɂ���ɂ́A���̂悤�ɂ���B
                //Microsoft.Win32.RegistryKey regkey =
                //    Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\test\sub", true);

                //���W�X�g���ɏ�������
                //��������������ށiREG_SZ�ŏ������܂��j
                regkey.SetValue("string", "StringValue");
                //�����iInt32�j���������ށiREG_DWORD�ŏ������܂��j
                regkey.SetValue("int", 100);
                //������z����������ށiREG_MULTI_SZ�ŏ������܂��j
                string[] s = new string[] { "1", "2", "3" };
                regkey.SetValue("StringArray", s);
                //�o�C�g�z����������ށiREG_BINARY�ŏ������܂��j
                byte[] bs = new byte[] { 0, 1, 2 };
                regkey.SetValue("Bytes", bs);

                //����
                regkey.Close();
                #endregion

                //reg
                textBox1.Text = ReadSetting("DataPath");
                //���݊m�F
                //      if (File.Exists(textBox1.Text))
                //      {
                //          // filePath�̃t�@�C���͑��݂���
                //      }
                //      else
                //      {
                //          // filePath�̃t�@�C���͑��݂��Ȃ�
                //      }

                if (Directory.Exists(textBox1.Text))
                {
                    // dirPath�̃f�B���N�g���͑��݂���
                    datafile = textBox1.Text + @"\bsc5.dat";
                }
                else
                {
                    // dirPath�̃f�B���N�g���͑��݂��Ȃ�
                    datafile = @"bsc5.dat";
                }
                //���݊m�F
                if (File.Exists(datafile))
                {
                    // filePath�̃t�@�C���͑��݂���

                    // �t�@�C�����J�������������h�~
                    // �R�[�h�y�[�W �G���R�[�f�B���O �v���o�C�_�[��o�^
                    Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
                    using (StreamReader file = new StreamReader(datafile, Encoding.GetEncoding("shift-jis")))
                    {
                        // �s���܂łP�s���ǂݍ���
                        while (file.Peek() != -1)
                        {
                            string line = file.ReadLine();
                            if (line != null)
                            {
                                Star particle = new Star(line);
                                stars.Add(particle);
                                Console.WriteLine(line);
                            }
                        }
                    }


                }
                else
                {
                    // filePath�̃t�@�C���͑��݂��Ȃ�
                }
            }
            //////////////////////

            tenqu1.stars = stars;
            hip = new HipStar(stars);
            if (stars.Count < 10)
            {
                hip.doset();
            }
            //       createCeleLines();

            tenqu1.Move = true;
        }

        #region Graphic
        /// <summary>
        /// ������̕`��A��]�A��ʒu�w��
        /// </summary>
        /// <param name="g">�`����Graphics�I�u�W�F�N�g</param>
        /// <param name="s">�`�悷�镶����</param>
        /// <param name="f">�����̃t�H���g</param>
        /// <param name="brush">�`��p�u���V</param>
        /// <param name="x">��ʒu��X���W</param>
        /// <param name="y">��ʒu��Y���W</param>
        /// <param name="deg">��]�p�x�i�x���A���v���肪���j</param>
        /// <param name="format">��ʒu��StringFormat�N���X�I�u�W�F�N�g�Ŏw�肵�܂�</param>
        public void DrawString(Graphics g, string s, Font f, Brush brush, float x, float y, float deg, StringFormat format)
        {
            using (var pathText = new System.Drawing.Drawing2D.GraphicsPath())  // �p�X�̍쐬
            using (var mat = new System.Drawing.Drawing2D.Matrix())             // �A�t�B���ϊ��s��
            {
                // �`��pFormat
                var formatTemp = (StringFormat)format.Clone();
                formatTemp.Alignment = StringAlignment.Near;        // ���񂹂ɏC��
                formatTemp.LineAlignment = StringAlignment.Near;    // ��񂹂ɏC��

                // ������̕`��
                pathText.AddString(
                        s,
                        f.FontFamily,
                        (int)f.Style,
                        f.SizeInPoints,
                        new PointF(0, 0),
                        format);
                formatTemp.Dispose();

                // �����̗̈�擾
                var rect = pathText.GetBounds();

                // ��]���S��X���W
                float px;
                switch (format.Alignment)
                {
                    case StringAlignment.Near:
                        px = rect.Left;
                        break;
                    case StringAlignment.Center:
                        px = rect.Left + rect.Width / 2f;
                        break;
                    case StringAlignment.Far:
                        px = rect.Right;
                        break;
                    default:
                        px = 0;
                        break;
                }
                // ��]���S��Y���W
                float py;
                switch (format.LineAlignment)
                {
                    case StringAlignment.Near:
                        py = rect.Top;
                        break;
                    case StringAlignment.Center:
                        py = rect.Top + rect.Height / 2f;
                        break;
                    case StringAlignment.Far:
                        py = rect.Bottom;
                        break;
                    default:
                        py = 0;
                        break;
                }

                // �����̉�]���S���W�����_�ֈړ�
                mat.Translate(-px, -py, System.Drawing.Drawing2D.MatrixOrder.Append);
                // �����̉�]
                mat.Rotate(deg, System.Drawing.Drawing2D.MatrixOrder.Append);
                // �\���ʒu�܂ňړ�
                mat.Translate(x, y, System.Drawing.Drawing2D.MatrixOrder.Append);

                // �p�X���A�t�B���ϊ�
                pathText.Transform(mat);

                // �`��
                g.FillPath(brush, pathText);
            }
        }

        #endregion

        static void ReadAllSettings()
        {
            try
            {
                var appSettings = ConfigurationManager.AppSettings;

                if (appSettings.Count == 0)
                {
                    Debug.WriteLine("AppSettings is empty.");
                }
                else
                {
                    foreach (var key in appSettings.AllKeys)
                    {
                        Debug.WriteLine("Key: {0} Value: {1}", key, appSettings[key]);
                    }
                }
            }
            catch (ConfigurationErrorsException)
            {
                Debug.WriteLine("Error reading app settings");
            }
        }

        static string ReadSetting(string key)
        {
            try
            {
                var appSettings = ConfigurationManager.AppSettings;
                string result = appSettings[key] ?? "Not Found";
                Debug.WriteLine(result);
                return result;
            }
            catch (ConfigurationErrorsException)
            {
                Debug.WriteLine("Error reading app settings");
            }
            return "";
        }

        static void AddUpdateAppSettings(string key, string value)
        {
            try
            {
                var configFile = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                var settings = configFile.AppSettings.Settings;
                if (settings[key] == null)
                {
                    settings.Add(key, value);
                }
                else
                {
                    settings[key].Value = value;
                }
                configFile.Save(ConfigurationSaveMode.Modified);
                ConfigurationManager.RefreshSection(configFile.AppSettings.SectionInformation.Name);
            }
            catch (ConfigurationErrorsException)
            {
                Debug.WriteLine("Error writing app settings");
            }
        }




        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            //      panel1_MouseMove(sender,new MouseEventArgs (MouseButtons.Left,0, MD.X, MD.Y,0));

            tenqu1.hScroll = hScrollBar1.Value * 0.01;
            label1.Text = (hScrollBar1.Value * 0.01).ToString("0.00");
        }

        private void tenqu1_Load(object sender, EventArgs e)
        {

        }

        private void ucSwitch2_CheckedChanged(object sender, BoolEventArgs e)
        {
            tenqu1.ShowHip = ucSwitch2.Checked;

        }

        private void ucSwitch1_CheckedChanged(object sender, BoolEventArgs e)
        {
           tenqu1.Showbsc5 = ucSwitch1.Checked;
        }
    }
}
