﻿namespace ucPgmac
{
    partial class ucSwitch
    {
        /// <summary> 
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region コンポーネント デザイナーで生成されたコード

        /// <summary> 
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を 
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // ucSwitch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "ucSwitch";
            this.Size = new System.Drawing.Size(116, 33);
            this.Load += new System.EventHandler(this.ucSwitch_Load);
            this.BackColorChanged += new System.EventHandler(this.ucSwitch_Resize);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.ucSwitch_Paint);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ucSwitch_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ucSwitch_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ucSwitch_MouseUp);
            this.Resize += new System.EventHandler(this.ucSwitch_Resize);
            this.ResumeLayout(false);

        }

        #endregion
    }
}
