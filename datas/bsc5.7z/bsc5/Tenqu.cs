﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using ucPgmac;
using System.Timers;
using static System.Windows.Forms.DataFormats;
//using static System.Net.Mime.MediaTypeNames;

namespace bsc5
{
    //http://tdc-www.harvard.edu/catalogs/index.html


    public partial class Tenqu : UserControl
    {
        Quaternion Mpos = new Quaternion();

        double AZMITH = 0;  //マウスのさす高度方位
        double ALTITUDE = 0;
        double RA = 0;      //天球座標
        double DEC = 0;     //天球座標
        double RAMouse = 0; //天球座標
        double DECMouse = 0;//天球座標
        private System.Timers.Timer aTimer;

        int dispmode = 0;
        float Magnitude = 1.0f;
        Quaternion tenqu = new Quaternion(0, 0, 1, 0);
        Quaternion horiq = new Quaternion(0, 0, 1, 0);
        Quaternion poiN = new Quaternion(0, 0, 1, 0);
        Quaternion poiS = new Quaternion(0, 0, -1, 0);

        const int DECCNT = 19;
        const int RACNT = 96;
        //X,Z平面　XはそのままCOS((int)(deg/10))なのでscaleとして使用できる?
        Quaternion[,] ptArrQ = new Quaternion[DECCNT, RACNT];//1h づつ０hから24hまで
        Quaternion[,] ptArrV = new Quaternion[DECCNT, RACNT];//1h づつ０hから24hまで
        Quaternion[] ptArrH = new Quaternion[RACNT];//0度　の　部分　1h づつ０hから24hまで

        Quaternion[] pStar;//
        Quaternion[] phStar;//

        Vector2 Center = new Vector2(100, 100);

        public List<Star> stars
        {
            get; set;
        }// = new List<Star>();

        float VmagMax = 0;
        double viewAzmith = 0;
        double viewAltitude = 0;

        public Cel cel
        {
            get; set;
        }
        public double hScroll = 0;

        public bool Move
        {
            get
            {
                return aTimer.Enabled;
            }
            set
            {
                aTimer.Enabled = value;
            }
        }


        public bool ShowHip
        {
            get; set;
        }
        public bool Showbsc5
        {
            get; set;
        }

        public Tenqu()
        {
            InitializeComponent();
            //ホイールイベントの追加  
            this.MouseWheel
                += new System.Windows.Forms.MouseEventHandler(this.this_MouseWheel);
            this.DoubleBuffered = true;

            // Create a timer with a two second interval.
            aTimer = new System.Timers.Timer(500);
            // Hook up the Elapsed event for the timer. 
            aTimer.Elapsed += OnTimedEvent;
            aTimer.AutoReset = true;
          //  aTimer.Enabled = true;
        }
        private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            tenqu_update();
            Console.WriteLine("The Elapsed event was raised at {0:HH:mm:ss.fff}",
                              e.SignalTime);
        }
        private void Tenqu_Load(object sender, EventArgs e)
        {
            Center = new Vector2(Width / 2, Height / 2);
            createCeleLines();
        }

        private void createCeleLines()
        {
            Quaternion[] ptArrDec = new Quaternion[10];//10deg づつ０度から９０度(north)まで
            Quaternion rt1h = Quaternion.CreateFromAxisAngle(new Vector3(0, 0, 1), (float)(Math.PI * 2 / RACNT));
            Quaternion rt10deg = Quaternion.CreateFromAxisAngle(new Vector3(0, 1, 0), (float)(Math.PI / 18.0));
            ptArrDec[0] = new Quaternion(1, 0, 0, 0);
            for (int i = 1; i < ptArrDec.Length; i++)
            {
                ptArrDec[i] = rt10deg * ptArrDec[i - 1] * Quaternion.Conjugate(rt10deg);
            }
            //-----------------------------------
            Quaternion rtXh = new Quaternion(0, 0, 1, 0);
            for (int j = 0; j < RACNT; j++)
            {
                for (int i = 0; i < 10; i++)
                {
                    ptArrQ[i + 9, j] = rtXh * ptArrDec[i] * Quaternion.Conjugate(rtXh);
                    ptArrQ[-i + 9, j] = ptArrQ[i + 9, j];
                    ptArrQ[-i + 9, j].Z = -ptArrQ[-i + 9, j].Z;
                }
                rtXh = rt1h * rtXh;
            }
        }
        private void rotateCeleLines(Quaternion Q)
        {
            Quaternion CQ = Quaternion.Conjugate(Q);
            //回転処理
            for (int j = 0; j < RACNT; j++)
            {
                for (int i = 0; i < DECCNT; i++)
                {
                    ptArrV[i, j] = Q * ptArrQ[i, j] * CQ * 180f * Magnitude;
                }
            }
        }

        private void drawCeleUnit(Graphics g)
        {
         //   return;
            Brush brush = new SolidBrush(HsvColor.cvt(BackColor, 0f, 0.4f));
            Font font = new Font(FontFamily.GenericSansSerif, 15F);
            var format = new StringFormat();
            format.Alignment = StringAlignment.Center;      // 左右方向は中心寄せ
            format.LineAlignment = StringAlignment.Center;  // 上下方向は中心寄せ

            double range = Width / Magnitude;
            int ra = 4 * (int)Cel.Map24(RA - range/15);
            int decs = (int)Cel.Map180(DEC - range)/10;
            int dece = decs + (int)(range * 2) / 10;
            if (decs < 1) decs = 1;
            if (dece > DECCNT) dece = DECCNT;
            int raskip = 4;
            int skip = 4;
            if (Magnitude < 2)
            {
                skip = 4;
                raskip = 8;
            }
            else if (Magnitude < 10)
            {
                skip = 2;
                raskip = 8;
            }
            else if (Magnitude < 15)
            {
                skip =1;
                raskip = 4;
            }
            else if (Magnitude < 30)
            {
                skip = 1;
                raskip = 2;
            }
            else
            {
                skip = 1;
                raskip = 1;
            }

            for (int i = 1; i < DECCNT-1; i+=skip)
            {
                Vector2 p0 = new Vector2(ptArrV[i, RACNT - raskip].X, ptArrV[i, RACNT - raskip].Y);
            //    float X0 = ptArrV[i, RACNT- raskip].X;
            //    float Y0 = ptArrV[i, RACNT- raskip].Y;
                for (int j = 0; j < RACNT; j += raskip)
                {
             //       float X = ptArrV[i, j].X;
             //       float Y = ptArrV[i, j].Y;
                    float Z = ptArrV[i, j].Z;

                    Vector2 ps = new Vector2(ptArrV[i, j].X, ptArrV[i, j].Y) ;
                //    ps = ps + Center;

                    RectangleF rct = new RectangleF(0, 0, Width, Height);
                    if (rct.Contains(ps.X,ps.Y) && Z > 0)  //    if (X > -Width / 2 && X < Width / 2 && Y > -Height / 2 && Y < Height / 2 && Z > 0)
                    {
                        Vector2 po = new Vector2(ptArrV[i-1, j].X, ptArrV[i-1, j].Y)-ps;
                 //       float Xo = ptArrV[i - 1, j].X - X;
                 //       float Yo = ptArrV[i - 1, j].Y - Y;
                        //     float deg = 0;// -(float)(Math.Atan2(X - X0, Y - Y0) * 180 / Math.PI);
                        float deg = 180 - (float)(Math.Atan2(po.X, po.Y) * 180 / Math.PI);
                        DrawString(g, ((90 - i * 10 ) > 0 ? "+" : "") + (90 - i * 10 ).ToString() + "°", font, Brushes.Gray, (ps.X + p0.X) / 2, (ps.Y + p0.Y) / 2, deg, format);

                        if (j % 4 == 0)
                            DrawString(g, (j * 24 / RACNT).ToString() + "h", font, Brushes.Gray, (-po.X / 5 + ps.X), (-po.Y / 5 + ps.Y), deg, format);
                        if (j % 4 == 1)
                            DrawString(g, (j * 24 / RACNT).ToString() + "h15m", font, Brushes.Gray, (-po.X / 5 + ps.X), (-po.Y / 5 + ps.Y), deg, format);
                        if (j % 4 == 2)
                            DrawString(g, (j * 24 / RACNT).ToString() + "h30m", font, Brushes.Gray, (-po.X / 5 + ps.X), (-po.Y / 5 + ps.Y), deg, format);
                        if (j % 4 == 3)
                            DrawString(g, (j * 24 / RACNT).ToString() + "h45m", font, Brushes.Gray, (-po.X / 5 + ps.X), (-po.Y / 5 + ps.Y), deg, format);
                    }
                    //    X0 = X;
                    //    Y0 = Y;
                    p0 = ps;
                }
                if (Magnitude > 20 && i > 1)
                {
                    for (int j = 0; j < RACNT; j += raskip)
                    {
                 //       float X = (ptArrV[i, j].X + ptArrV[i - 1, j].X) / 2;
                 //       float Y = (ptArrV[i, j].Y + ptArrV[i - 1, j].Y) / 2;
                        Vector2 ps = new Vector2((ptArrV[i, j].X + ptArrV[i - 1, j].X) / 2, (ptArrV[i, j].Y + ptArrV[i - 1, j].Y) / 2);
                        float Z = ptArrV[i, j].Z;

                        RectangleF rct = new RectangleF(0, 0, Width, Height);
                        if (rct.Contains(ps.X, ps.Y) && Z > 0) //if (ps.X > -Width / 2 && ps.X < Width / 2 && ps.Y > -Height / 2 && ps.Y < Height / 2 && Z > 0)
                        {
                            float Xo = ptArrV[i - 1, j].X - ps.X;
                            float Yo = ptArrV[i - 1, j].Y - ps.Y;
                            //     float deg = 0;// -(float)(Math.Atan2(X - X0, Y - Y0) * 180 / Math.PI);
                            float deg = 180 - (float)(Math.Atan2(Xo, Yo) * 180 / Math.PI);
                            DrawString(g, ((95 - i * 10) > 0 ? "+" : "") + (95 - i * 10).ToString() + "°", font, Brushes.Gray, (ps.X + p0.X) / 2, (ps.Y + p0.Y) / 2, deg, format);
                            //                       DrawString(g, (j * 24 / RACNT).ToString() + "h", font, Brushes.Gray, (Xo / 2 + X), (Yo / 2 + Y), deg, format);
                   //     X0 = X;
                   //     Y0 = Y;
                        p0 = ps;
                        }
                    }
                }
            }


        }
        //姿勢回転
        private void drawCeleLines(Graphics g)
        {
            Pen pen = new Pen(HsvColor.cvt(BackColor, 0f, 0.4f));
            Font font = new Font(FontFamily.GenericSansSerif, 15F);
            var format = new StringFormat();
            format.Alignment = StringAlignment.Center;      // 左右方向は中心寄せ
            format.LineAlignment = StringAlignment.Center;  // 上下方向は中心寄せ


            //描画処理　赤経線 
            int lpnskip =  RACNT / 24;

            for (int k = 0; k < RACNT; k += lpnskip)
            {
                int j = k;
                {
                    pen = new Pen(HsvColor.cvt(BackColor, 0f, 0.4f));

                    float X0 = ptArrV[1, j].X;
                    float Y0 = ptArrV[1, j].Y;
                    float Z0 = ptArrV[1, j].Z;
                    for (int i = 2; i < DECCNT - 1; i++)
                    {
                        float X = ptArrV[i, j].X;
                        float Y = ptArrV[i, j].Y;
                        float Z = ptArrV[i, j].Z;
                        if (Z > 0 && Z0 > 0)
                        {
                            g.DrawLine(pen, X0, Y0, X, Y);
                            //       g.DrawString((100-i*10).ToString(),font,Brushes.Gray,X0,Y0);
                            if (i % 3 == 0 || Magnitude > 15)
                            {
                                float deg = -(float)(Math.Atan2(X - X0, Y - Y0) * 180 / Math.PI);
                 //               DrawString(g, (j * 24 / RACNT).ToString() + "h", font, Brushes.Gray, (X0 + X) / 2, (Y0 + Y) / 2, deg, format);
                            }
                        }
                        X0 = X;
                        Y0 = Y;
                        Z0 = Z;
                    }
                }
            }
            if (Magnitude > 15)
            {
                for (int k = 2; k < RACNT; k += lpnskip)
                {
                    int j = k;
                    {
                        pen = new Pen(HsvColor.cvt(BackColor, 0f, 0.3f));

                        float X0 = ptArrV[1, j].X;
                        float Y0 = ptArrV[1, j].Y;
                        float Z0 = ptArrV[1, j].Z;
                        for (int i = 2; i < DECCNT - 1; i++)
                        {
                            float X = ptArrV[i, j].X;
                            float Y = ptArrV[i, j].Y;
                            float Z = ptArrV[i, j].Z;
                            if (Z > 0 && Z0 > 0)
                            {
                                g.DrawLine(pen, X0, Y0, X, Y);
                                //       g.DrawString((100-i*10).ToString(),font,Brushes.Gray,X0,Y0);
                          //      if (i % 3 == 0)
                                {
                                    float deg = -(float)(Math.Atan2(X - X0, Y - Y0) * 180 / Math.PI);
                     //               DrawString(g, (j * 24 / RACNT).ToString() + "h30m", font, Brushes.Gray, (X0 + X) / 2, (Y0 + Y) / 2, deg, format);
                                }
                            }
                            X0 = X;
                            Y0 = Y;
                            Z0 = Z;
                        }
                    }
                }
            }
            if (Magnitude > 30)
            {
                for (int k = 1; k < RACNT; k += lpnskip/2)
                {
                    int j = k;
                    {
                        pen = new Pen(HsvColor.cvt(BackColor, 0f, 0.3f));

                        float X0 = ptArrV[1, j].X;
                        float Y0 = ptArrV[1, j].Y;
                        float Z0 = ptArrV[1, j].Z;
                        for (int i = 2; i < DECCNT - 1; i++)
                        {
                            float X = ptArrV[i, j].X;
                            float Y = ptArrV[i, j].Y;
                            float Z = ptArrV[i, j].Z;
                            if (Z > 0 && Z0 > 0)
                            {
                                g.DrawLine(pen, X0, Y0, X, Y);
                                //       g.DrawString((100-i*10).ToString(),font,Brushes.Gray,X0,Y0);
                                    float deg = -(float)(Math.Atan2(X - X0, Y - Y0) * 180 / Math.PI);
                                if (k % 4 == 1)
                                {
              //                      DrawString(g, (j * 24 / RACNT).ToString() + "h15m", font, Brushes.Gray, (X0 + X) / 2, (Y0 + Y) / 2, deg, format);
                                }
                                else
                                {
              //                      DrawString(g, (j * 24 / RACNT).ToString() + "h45m", font, Brushes.Gray, (X0 + X) / 2, (Y0 + Y) / 2, deg, format);
                                }
                            }
                            X0 = X;
                            Y0 = Y;
                            Z0 = Z;
                        }
                    }
                }
            }


            pen = new Pen(HsvColor.cvt(BackColor, 0f, 0.4f));

            {//北極軸
                float X0 = ptArrV[0, 0].X;
                float Y0 = ptArrV[0, 0].Y;
                float X1 =  ( ptArrV[1, 0].X - X0)/10;
                float Y1 =  ( ptArrV[1, 0].Y - Y0)/10;
                g.DrawLine(pen, X0, Y0, X0 + X1, Y0 + Y1);
                g.DrawLine(pen, X0, Y0, X0 - X1, Y0 - Y1);
                g.DrawLine(pen, X0, Y0, X0 + Y1, Y0 - X1);
                g.DrawLine(pen, X0, Y0, X0 - Y1, Y0 + X1);
            }


            //描画処理　赤緯線
            for (int i = 1; i < 9; i++)
            {
                float X0 = ptArrV[i, RACNT - 1].X;
                float Y0 = ptArrV[i, RACNT - 1].Y;
                float Z0 = ptArrV[i, RACNT - 1].Z;
                for (int j = 0; j < RACNT; j++)
                {
                    float X = ptArrV[i, j].X;
                    float Y = ptArrV[i, j].Y;
                    float Z = ptArrV[i, j].Z;
                    if (Z > 0 && Z0 > 0)
                    {
                        g.DrawLine(pen, X0, Y0, X, Y);
                        if (j % 8 == 1 || (Magnitude > 15 && (j % 8 == 5)) || (Magnitude > 30))
                        {
                            float deg = 0;// -(float)(Math.Atan2(X - X0, Y - Y0) * 180 / Math.PI);
              //              DrawString(g,  "+"+(90-i*10).ToString() + "°", font, Brushes.Gray, (X0 + X) / 2, (Y0 + Y) / 2, deg, format);
                        }

                    }
                    X0 = X;
                    Y0 = Y;
                    Z0 = Z;
                }
            }
            //5度
            if (Magnitude > 15)
            {
                pen = new Pen(HsvColor.cvt(BackColor, 0f, 0.2f));
                for (int i = 1; i < DECCNT-1; i++)
                {
                    Quaternion m = (ptArrV[i, RACNT - 1] + ptArrV[i + 1, RACNT - 1]) * 0.5f;
                    float X0 = m.X;
                    float Y0 = m.Y;
                    float Z0 = m.Z;

                    for (int j = 0; j < RACNT; j++)
                    {
                        m = (ptArrV[i, j] + ptArrV[i + 1, j]) * 0.5f;
                        float X = m.X;
                        float Y = m.Y;
                        float Z = m.Z;
                        if (Z > 0 && Z0 > 0)
                        {
                            g.DrawLine(pen, X0, Y0, X, Y);
                            if (j % 8 == 1 || (Magnitude > 15 && (j % 8 == 5)) || (Magnitude > 30))
                            {
                                float deg = 0;// -(float)(Math.Atan2(X - X0, Y - Y0) * 180 / Math.PI);
                   //             DrawString(g, "+" + (95 - i * 10).ToString() + "°", font, Brushes.Gray, (X0 + X) / 2, (Y0 + Y) / 2, deg, format);
                            }
                        }
                        X0 = X;
                        Y0 = Y;
                        Z0 = Z;
                    }
                }
                pen = new Pen(HsvColor.cvt(BackColor, 0f, 0.4f));
            }

            {//　赤緯０度
                int i = 9;
                float X0 = ptArrV[i, RACNT - 1].X;
                float Y0 = ptArrV[i, RACNT - 1].Y;
                float Z0 = ptArrV[i, RACNT - 1].Z;
                for (int j = 0; j < RACNT; j++)
                {
                    float X = ptArrV[i, j].X;
                    float Y = ptArrV[i, j].Y;
                    float Z = ptArrV[i, j].Z;
                    if (Z > 0 && Z0 > 0)
                    {
                        g.DrawLine(Pens.Red, X0, Y0, X, Y);
                    }
                    X0 = X;
                    Y0 = Y;
                    Z0 = Z;
                }
            }
            pen = new Pen(HsvColor.cvt(BackColor, 0f, 0.4f));

            for (int i = 10; i < DECCNT; i++)
            {
                float X0 = ptArrV[i, RACNT - 1].X;
                float Y0 = ptArrV[i, RACNT - 1].Y;
                float Z0 = ptArrV[i, RACNT - 1].Z;
                for (int j = 0; j < RACNT; j++)
                {
                    float X = ptArrV[i, j].X;
                    float Y = ptArrV[i, j].Y;
                    float Z = ptArrV[i, j].Z;
                    if (Z > 0 && Z0 > 0)
                    {
                        g.DrawLine(pen, X0, Y0, X, Y);
                        if (j % 8 == 1 || (Magnitude > 15 && (j % 8 == 5)) || (Magnitude > 30))
                        {
                            float deg = 0;// -(float)(Math.Atan2(X - X0, Y - Y0) * 180 / Math.PI);
         //                   DrawString(g, "-"+(i * 10-90).ToString() + "°", font, Brushes.Gray, (X0 + X) / 2, (Y0 + Y) / 2, deg, format);
                        }
                    }
                    X0 = X;
                    Y0 = Y;
                    Z0 = Z;
                }
            }
            
        }

        private void rotateStars(Quaternion Q)
        {
            if (stars !=null && stars.Count > 0)
            {
                pStar = new Quaternion[stars.Count];
                int i = 0;
                foreach (Star s in stars)
                {
                    if ((s.hip < 0 && Showbsc5) || (s.hip > 0 && ShowHip))
                    {
                        if (s.Vmag < 3.5f + Magnitude / 3.2f) // && s.Name.IndexOf("Ori")>0)
                        {
                            pStar[i] = tenqu * s.Quaternion * Quaternion.Conjugate(tenqu) * 180 * Magnitude;
                            if (pStar[i].Z > 0)
                            {
                                if(s.hip > 0) pStar[i].W = 1f;
                                float size = mag2size((float)s.Vmag);
                                pStar[i].Z = size;

                                byte[] dst = BitConverter.GetBytes(s.color.ToArgb());
                                pStar[i].W = BitConverter.ToSingle(dst); //;(float)(s.color.ToArgb());
                                //復原　復元
                         //       dst = BitConverter.GetBytes(pStar[i].W);
                         //       int argb = BitConverter.ToInt32(dst); //;(float)(s.color.ToArgb());

                            }
                            i++;
                        }
                    }
                }
             //   Array.Resize(ref pStar, i);
            }
        }

        private float mag2size(float mag)
        {
            if (mag > 4) mag = 4 + (mag - 4)*0.5f;
            float size = 4f - mag * 0.8f + Magnitude * 0.04f;
      //      if (size <= 0.5f) size = 0.5f;

            return size;
        }

        private void drawStars(Graphics g)
        {
            SolidBrush hBrush = new SolidBrush(Color.FromArgb(150, 0, 255, 0));
            SolidBrush Brush = new SolidBrush(Color.FromArgb(100, 250,250, 250));
            //Quaternion
            if (pStar != null && pStar.Length > 0)
            {
                foreach (Quaternion s in pStar)
                {
                    if (s.Z > 0)
                    {
                        float x = s.X;
                        float y = s.Y;
                        //復原　復元
                        if (s.W != 0f)
                        {
                            byte[] dst = BitConverter.GetBytes(s.W);
                            int argb = BitConverter.ToInt32(dst); //;(float)(s.color.ToArgb());
                            // hBrush = new SolidBrush(Color.FromArgb(argb));
                            g.DrawEllipse(new Pen(Color.FromArgb(argb)), x - s.Z, y - s.Z, s.Z * 2, s.Z * 2);
                        }
                        else
                        {
                            g.FillEllipse(Brush, x - s.Z, y - s.Z, s.Z * 2, s.Z * 2);
                          //   g.DrawEllipse(Pens.White, x - s.Z, y - s.Z, s.Z * 2, s.Z * 2);
                        }
                    }
                }

                Font font = new Font(FontFamily.GenericSansSerif, 8f);
                for (int i = 0; i < 11; i++)
                {
                    float size = mag2size((float)i);
                    g.DrawString(i.ToString(), font, Brushes.Yellow, i * 25 + 20 - Width / 2, 5 - Height / 2);
                    g.FillEllipse(Brush, i * 25 + 25- size- Width / 2, 20 - Height / 2, size * 2, size * 2);
                }
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.TranslateTransform(Width / 2, Height / 2);
            //    g.ScaleTransform((float)Magnitude, (float)Magnitude);
            int dd = 180;
            //      g.FillRectangle(Brushes.DarkSlateBlue, -this.Width / 2, -this.Height / 2, this.Width, this.Height);

            drawCeleLines(g);
            drawCeleUnit(g);
            drawStars(g);

            Quaternion Choriq = Quaternion.Conjugate(horiq);
            //回転処理
            for (int j = 0; j < RACNT; j++)
            {
                ptArrH[j] = horiq * ptArrQ[9, j] * Choriq * 180f * Magnitude;
            }
            float X0 = ptArrH[RACNT - 1].X;
            float Y0 = ptArrH[RACNT - 1].Y;
            float Z0 = ptArrH[RACNT - 1].Z;
            for (int j = 0; j < RACNT; j++)
            {
                float X = ptArrH[j].X;
                float Y = ptArrH[j].Y;
                float Z = ptArrH[j].Z;
                if (Z > 0 && Z0 > 0)
                {
                    g.DrawLine(Pens.LimeGreen, X0, Y0, X, Y);
                }
                X0 = X;
                Y0 = Y;
                Z0 = Z;
            }

            Font font = new Font(FontFamily.GenericSansSerif, 12f);
            var format = new StringFormat();
            format.Alignment = StringAlignment.Center;      // 左右方向は中心寄せ
            format.LineAlignment = StringAlignment.Far;  // 上下方向は中心寄せ            //描画処理　赤経線

            int ind = 0;
            int stp = 3 * RACNT / 24;
            if (ptArrH[ind].Z > 0)
                g.DrawString("W", font, Brushes.Yellow, ptArrH[ind].X, ptArrH[ind].Y, format);
            ind += stp;
            if (ptArrH[ind].Z > 0)
                g.DrawString("SW", font, Brushes.Yellow, ptArrH[ind].X, ptArrH[ind].Y, format);
            ind += stp;
            if (ptArrH[ind].Z > 0)
                g.DrawString("S", font, Brushes.Yellow, ptArrH[ind].X, ptArrH[ind].Y, format);
            ind += stp;
            if (ptArrH[ind].Z > 0)
                g.DrawString("SE", font, Brushes.Yellow, ptArrH[ind].X, ptArrH[ind].Y, format);
            ind += stp;
            if (ptArrH[ind].Z > 0)
                g.DrawString("E", font, Brushes.Yellow, ptArrH[ind].X, ptArrH[ind].Y, format);
            ind += stp;
            if (ptArrH[ind].Z > 0)
                g.DrawString("NE", font, Brushes.Yellow, ptArrH[ind].X, ptArrH[ind].Y, format);
            ind += stp;
            if (ptArrH[ind].Z > 0)
                g.DrawString("N", font, Brushes.Yellow, ptArrH[ind].X, ptArrH[ind].Y, format);
            ind += stp;
            if (ptArrH[ind].Z > 0)
                g.DrawString("NW", font, Brushes.Yellow, ptArrH[ind].X, ptArrH[ind].Y, format);
            ind += stp;
                                                                                                        

         //   g.DrawString("方位" + AZMITH.ToString() + "°" + "高度" +ALTITUDE.ToString()+"°", font, Brushes.Yellow, -this.Width / 2, 0);

            //下段
            string Viewstate = (RA).ToString("0.00000") + "  " + (DEC).ToString("0.00000");
            g.DrawString(Viewstate, font, Brushes.Yellow, 0, Height / 2 - 15);

            string Viewstatem = (RAMouse).ToString("0.00000") + "  " + (DECMouse).ToString("0.00000");
            g.DrawString(Viewstatem, font, Brushes.Yellow, MD.X- Width / 2+20, MD.Y- Height / 2-20);

            g.DrawString("x" + Magnitude.ToString("0.0") + "方位" + AZMITH.ToString() + "°" + "高度" + ALTITUDE.ToString() + "°", font, Brushes.Yellow, -this.Width / 2, this.Height/2-20);



        }

        private void tenqu_update()
        {
            tenqu = Quaternion.CreateFromYawPitchRoll(0f, (float)(viewAltitude / 180 * Math.PI), 0f)//
               * Quaternion.CreateFromYawPitchRoll((float)(viewAzmith / 180 * Math.PI), (float)(cel.Latitude / 180 * Math.PI), 0f)//(float)(cel.Latitude / 180 * Math.PI)
            * Quaternion.CreateFromAxisAngle(new Vector3(0, 0, -1), (float)((cel.LSTNow() - 6 + hScroll) / 12.0 * Math.PI));
            //地平線
            horiq = Quaternion.CreateFromYawPitchRoll(0f, (float)(viewAltitude / 180 * Math.PI), 0f)//
                   * Quaternion.CreateFromYawPitchRoll((float)(viewAzmith / 180 * Math.PI), (float)(Math.PI / 2), 0f);

            //  Debug.WriteLine(cel.LSTNow());

            //表示中心の天球座標
            Quaternion Vpos = new Quaternion(0, 0, 1, 0);
            Vpos = Quaternion.Conjugate(tenqu) * Vpos * tenqu;
            RA = Cel.Map24(-Math.Atan2(Vpos.X, Vpos.Y) * 12 / Math.PI - 6);
            double l = Math.Sqrt(Vpos.Z  * Vpos.Z);
            DEC = Math.Atan2(Vpos.Z,1.0- l) * 180 / Math.PI;

            rotateCeleLines(tenqu);
            rotateStars(tenqu);
            this.Invalidate();

        }

        private void this_MouseWheel(object sender, MouseEventArgs e)
        {
            if (e.Delta > 0)
            {
                if (Magnitude < 200) Magnitude *= 1.1f;
            }
            else
            {
                if (Magnitude > 1) Magnitude /= 1.1f;
            }
            tenqu_update();

        }

        private void panel1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            dispmode++;
            if (dispmode > 2) dispmode = 0;
            this.Refresh();
        }

        Point MD = new Point(0, 0);

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            MD = e.Location;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            Point MM = e.Location; 
            if (e.Button == MouseButtons.Left)
            {
                
                int dx = MM.X - MD.X;
                int dy = MM.Y - MD.Y;
                if (true)
                {
                    viewAzmith += (float)dx / (Magnitude * 3.0);
                    if (viewAzmith > 360.0) viewAzmith -= 360;
                    if (viewAzmith < 0f) viewAzmith += 360.0;
                    viewAltitude -= (float)dy / (Magnitude * 3.0);
                    if (viewAltitude > 90.0) viewAltitude = 90.0;
                    if (viewAltitude < -90.0) viewAltitude = -90.0;
                    //    tenqu = Quaternion.CreateFromYawPitchRoll(0f, (float)(viewAltitude / 180 * Math.PI),  0f)//
                    //          * Quaternion.CreateFromYawPitchRoll((float)(viewAzmith / 180 * Math.PI), (float)((cel.Latitude) * Math.PI / 180), 0f)//(float)(viewAltitude / 180 * Math.PI)
                    //          * Quaternion.CreateFromYawPitchRoll((float)((cel.LSTNow()-0)/12*Math.PI),0, 0f);

                }
                else
                {
                    int ox = MD.X - this.Width / 2;
                    int oy = MD.Y - this.Height / 2;
                    float ln = (float)Math.Sqrt(ox * ox + oy * oy) / this.Width * 2;
                    ln = ln * ln;
                    double pr = Math.Atan2(oy, ox);
                    double r = Math.Atan2(MM.Y - this.Height / 2, MM.X - this.Width / 2);
                    r = r - pr;
                    tenqu = Quaternion.CreateFromAxisAngle(new Vector3(0, 0, 1), (float)r * ln) * tenqu;
                    tenqu = Quaternion.CreateFromAxisAngle(new Vector3(0, 1, 0), (float)dx / 200.0f / Magnitude * (1f - ln)) * tenqu;
                    tenqu = Quaternion.CreateFromAxisAngle(new Vector3(-1, 0, 0), (float)dy / 200.0f / Magnitude * (1f - ln)) * tenqu;
                }
                tenqu_update();
            }
            double xx =( MM.X - this.Width / 2) / (180 * Magnitude);
            double yy =( MM.Y - this.Height / 2) / (180 * Magnitude);

            double len = Math.Sqrt(1.0 - xx * xx - yy * yy);

            Quaternion Vpos = new Quaternion((float)xx, (float)yy, (float)len, 0);
            Quaternion Choriq = Quaternion.Conjugate(horiq);
            Mpos = (Choriq * Vpos * horiq);
            ALTITUDE = (Math.Atan2(Mpos.Z, Math.Sqrt(1.0 - Mpos.Z * Mpos.Z)) * 180.0 / Math.PI);
            AZMITH = Cel.Map360(-Math.Atan2(Mpos.X, Mpos.Y) * 180.0 / Math.PI );

            Quaternion VposMouse = Quaternion.Conjugate(tenqu) * Vpos * tenqu;
            RAMouse = Cel.Map24(-Math.Atan2(VposMouse.X, VposMouse.Y) * 12.0 / Math.PI - 6.0);
            double l = Math.Sqrt(1-VposMouse.Z * VposMouse.Z);
            DECMouse = Math.Atan2(VposMouse.Z,  l) * 180.0 / Math.PI;

            this.Refresh();
            MD = MM;


        }

        #region Graphic
        /// <summary>
        /// 文字列の描画、回転、基準位置指定
        /// </summary>
        /// <param name="g">描画先のGraphicsオブジェクト</param>
        /// <param name="s">描画する文字列</param>
        /// <param name="f">文字のフォント</param>
        /// <param name="brush">描画用ブラシ</param>
        /// <param name="x">基準位置のX座標</param>
        /// <param name="y">基準位置のY座標</param>
        /// <param name="deg">回転角度（度数、時計周りが正）</param>
        /// <param name="format">基準位置をStringFormatクラスオブジェクトで指定します</param>
        public void DrawString(Graphics g, string s, Font f, Brush brush, float x, float y, float deg, StringFormat format)
        {
            using (var pathText = new System.Drawing.Drawing2D.GraphicsPath())  // パスの作成
            using (var mat = new System.Drawing.Drawing2D.Matrix())             // アフィン変換行列
            {
                // 描画用Format
                var formatTemp = (StringFormat)format.Clone();
                formatTemp.Alignment = StringAlignment.Near;        // 左寄せに修正
                formatTemp.LineAlignment = StringAlignment.Near;    // 上寄せに修正

                // 文字列の描画
                pathText.AddString(
                        s,
                        f.FontFamily,
                        (int)f.Style,
                        f.SizeInPoints,
                        new PointF(0, 0),
                        format);
                formatTemp.Dispose();

                // 文字の領域取得
                var rect = pathText.GetBounds();

                // 回転中心のX座標
                float px;
                switch (format.Alignment)
                {
                    case StringAlignment.Near:
                        px = rect.Left;
                        break;
                    case StringAlignment.Center:
                        px = rect.Left + rect.Width / 2f;
                        break;
                    case StringAlignment.Far:
                        px = rect.Right;
                        break;
                    default:
                        px = 0;
                        break;
                }
                // 回転中心のY座標
                float py;
                switch (format.LineAlignment)
                {
                    case StringAlignment.Near:
                        py = rect.Top;
                        break;
                    case StringAlignment.Center:
                        py = rect.Top + rect.Height / 2f;
                        break;
                    case StringAlignment.Far:
                        py = rect.Bottom;
                        break;
                    default:
                        py = 0;
                        break;
                }

                // 文字の回転中心座標を原点へ移動
                mat.Translate(-px, -py, System.Drawing.Drawing2D.MatrixOrder.Append);
                // 文字の回転
                mat.Rotate(deg, System.Drawing.Drawing2D.MatrixOrder.Append);
                // 表示位置まで移動
                mat.Translate(x, y, System.Drawing.Drawing2D.MatrixOrder.Append);

                // パスをアフィン変換
                pathText.Transform(mat);

                // 描画
                g.FillPath(brush, pathText);
            }
        }

        #endregion


        private void Tenqu_Resize(object sender, EventArgs e)
        {
            Center = new Vector2(Width / 2, Height / 2);
            Refresh();
        }
    }
}
