﻿namespace bsc5
{
    partial class Tenqu
    {
        /// <summary> 
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region コンポーネント デザイナーで生成されたコード

        /// <summary> 
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を 
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            SuspendLayout();
            // 
            // Tenqu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkSlateBlue;
            Name = "Tenqu";
            Size = new Size(360, 360);
            Load += Tenqu_Load;
            Paint += panel1_Paint;
            MouseDown += panel1_MouseDown;
            MouseMove += panel1_MouseMove;
            Resize += Tenqu_Resize;
            ResumeLayout(false);
        }

        #endregion
    }
}
