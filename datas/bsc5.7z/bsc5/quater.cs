﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using System.Configuration;
using System.Diagnostics;

namespace ucPgmac
{
    public class BoolEventArgs
    {
        public BoolEventArgs(bool value) { Value = value; }
        public bool Value { get; } // readonly
    }
    public delegate void BoolEventHandler(object sender, BoolEventArgs e);
    public class SampleEventArgs
    {
        public SampleEventArgs(string value) { Value = value; }
        public string Value { get; } // readonly
    }
    public delegate void SampleEventHandler(object sender, SampleEventArgs e);

    public class CelChangeEventArgs : EventArgs
    {
        //PointCelにしちゃったほうがいい？ ->しちゃった
        public PointCel Value { get; } // readonly
        public CelChangeEventArgs(PointCel value) { Value = value; }
        public CelChangeEventArgs(double _ra, double _dec) { Value = new PointCel(_ra, _dec); }
    }
    public delegate void CelEventHandler(object sender, CelChangeEventArgs e);


    /// <summary>
    /// Celestorial Utils
    /// </summary>
    public class Cel
    {
        public double Latitude
        {
            get; set;
        }

        public double Longitude
        {
            get; set;
        }

        /*  Compute the Julian Day for the given date */
        /*  Julian Date is the number of days since noon of Jan 1 4713 B.C. */
        public static double CalcJD(int ny, int nm, int nd, double ut)
        {
            double A, B, C, D, jd, day;

            day = nd + ut / 24.0;
            if ((nm == 1) || (nm == 2))
            {
                ny = ny - 1;
                nm = nm + 12;
            }

            if (((double)ny + nm / 12.0 + day / 365.25) >=
              (1582.0 + 10.0 / 12.0 + 15.0 / 365.25))
            {
                A = ((int)(ny / 100.0));
                B = 2.0 - A + (int)(A / 4.0);
            }
            else
            {
                B = 0.0;
            }

            if (ny < 0.0)
            {
                C = (int)((365.25 * (double)ny) - 0.75);
            }
            else
            {
                C = (int)(365.25 * (double)ny);
            }

            D = (int)(30.6001 * (double)(nm + 1));
            jd = B + C + D + day + 1720994.5;
            return (jd);
        }


        /* Calculate the Julian date with millisecond resolution */

        public static double JDNow()
        {
            double ut, jd;

            /* Use gettimeofday and timeval to capture microseconds */

            /* Copy seconds part to convert to UTC */

            /* Save microseconds part to handle milliseconds of UTC */

            /* Convert unix time now to utc */
            /* Copy values pointed to by g to variables we will use later */

            DateTime t = DateTime.UtcNow;

            /* Convert the microseconds part to milliseconds */
            //milliseconds = usecs/1000;

            /* Calculate floating point ut in hours */
            ut = ((double)t.Millisecond) / 3600000.0 + ((double)t.Second) / 3600.0 + ((double)t.Minute) / 60.0 + ((double)t.Hour);
            jd = CalcJD(t.Year, t.Month, t.Day, ut);

            /* To test for specific jd change this value and uncomment */
            /* jd = 2462088.69;  */

            return (jd);
        }

        /* Local sidereal time */
        /*  Compute Greenwich Mean Sidereal Time (gmst) */
        /*  TU is number of Julian centuries since 2000 January 1.5 */
        /*  Expression for gmst from the Astronomical Almanac Supplement */

        public static double CalcLST(int year, int month, int day, double ut, double glong)
        {
            double TU, TU2, TU3, T0;
            double gmst, lmst;

            TU = (CalcJD(year, month, day, 0.0) - 2451545.0) / 36525.0;
            TU2 = TU * TU;
            TU3 = TU2 * TU;
            T0 =
                (24110.54841 / 3600.0) +
                8640184.812866 / 3600.0 * TU + 0.093104 / 3600.0 * TU2 -
                6.2e-6 / 3600.0 * TU3;
            T0 = Map24(T0);

            gmst = Map24(T0 + ut * 1.002737909);
            lmst = 24.0 * frac((gmst - glong / 15.0) / 24.0);
            return (lmst);
        }
        /* Calculate the local sidereal time with millisecond resolution */
        /// <summary>
        /// 24 hour format Need Longitude
        /// </summary>
        /// <returns></returns>

        public double LSTNow()
        {
            double ut, lst;
            DateTime t = DateTime.UtcNow;

            ut = ((double)t.Millisecond) / 3600000.0 + ((double)t.Second) / 3600.0 + ((double)t.Minute) / 60.0 + ((double)t.Hour);
            double glong = Longitude;
            lst = CalcLST(t.Year, t.Month, t.Day, ut, glong);
            return (lst);
        }

        public static double LSTNow(double siteLongitude)
        {
            double ut, lst;
            DateTime t = DateTime.UtcNow;

            ut = ((double)t.Millisecond) / 3600000.0 + ((double)t.Second) / 3600.0 + ((double)t.Minute) / 60.0 + ((double)t.Hour);
            lst = CalcLST(t.Year, t.Month, t.Day, ut, siteLongitude);
            return (lst);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="str"></param>
        /// <param name="ra"></param>
        /// <param name="dec"></param>
        /// <returns></returns>
        public static bool RaDecStringToEquatorial(string str, ref double ra, ref double dec)
        {
            //transrate 
            if (str == null) return false;

            string[] ss = str.Split(' ');
            if (ss.Length < 6) return false;

            int i = 0;
            bool succ = false;
            while (i + 2 < ss.Length)
            {
                double h, m, s;
                if (!double.TryParse(ss[i++], out h)) continue;
                if (!double.TryParse(ss[i++], out m)) continue;
                if (!double.TryParse(ss[i++], out s)) continue;
                ra = h + m / 60 + s / 3600;
                succ = true;
                break;
            }
            if (succ)
                while (i + 2 < ss.Length)
                {
                    double d, m, s;
                    if (!double.TryParse(ss[i++], out d)) continue;
                    if (!double.TryParse(ss[i++], out m)) continue;
                    if (!double.TryParse(ss[i++], out s)) continue;
                    if (d < 0) dec = d - m / 60 - s / 3600;
                    else dec = d + m / 60 + s / 3600;
                    //success
                    return true;
                }
            return false;
        }

        /// <summary>
        /// need Latitude of Site
        /// </summary>
        /// <param name="ha"></param>
        /// <param name="dec"></param>
        /// <param name="az"></param>
        /// <param name="alt"></param>
        public void EquatorialToHorizontal(double ha, double dec, ref double az, ref double alt)
        {
            double phi, altitude, azimuth;

            ha = ha * Math.PI / 12.0;
            phi = Latitude * Math.PI / 180.0;
            dec = dec * Math.PI / 180.0;
            altitude = Math.Asin(Math.Sin(phi) * Math.Sin(dec) + Math.Cos(phi) * Math.Cos(dec) * Math.Cos(ha));
            altitude = altitude * 180.0 / Math.PI;
            azimuth = Math.Atan2(-Math.Cos(dec) * Math.Sin(ha),
              Math.Sin(dec) * Math.Cos(phi) - Math.Sin(phi) * Math.Cos(dec) * Math.Cos(ha));
            azimuth = azimuth * 180.0 / Math.PI;

            azimuth = Map360(azimuth);

            alt = altitude;
            az = azimuth;
        }
        /* Fractional part */
        public static double frac(double x)
        {
            x -= (int)x;
            return ((x < 0) ? x + 1.0 : x);
        }
        /* Map a time in hours to the range  0  to 24 */
        public static double Map24(double hour)
        {
            int n;

            if (hour < 0.0)
            {
                n = (int)(hour / 24.0) - 1;
                return (hour - n * 24.0);
            }
            else if (hour >= 24.0)
            {
                n = (int)(hour / 24.0);
                return (hour - n * 24.0);
            }
            else
            {
                return (hour);
            }
        }
        /* Map an hourangle in hours to  -12 <= ha < +12 */
        public static double Map12(double hour)
        {
            double hour24;

            hour24 = Map24(hour);

            if (hour24 >= 12.0)
            {
                return (hour24 - 24.0);
            }
            else
            {
                return (hour24);
            }
        }

        /* Map an angle in degrees to  0 <= angle < 360 */
        public static double Map360(double angle)
        {
            int n;

            if (angle < 0.0)
            {
                n = (int)(angle / 360.0) - 1;
                return (angle - n * 360.0);
            }
            else if (angle >= 360.0)
            {
                n = (int)(angle / 360.0);
                return (angle - n * 360.0);
            }
            else
            {
                return (angle);
            }
        }

        /* Map an angle in degrees to -180 <= angle < 180 */
        public static double Map180(double angle)
        {
            double angle360;
            angle360 = Map360(angle);

            if (angle360 >= 180.0)
            {
                return (angle360 - 360.0);
            }
            else
            {
                return (angle360);
            }
        }

        /// "00 24 05.2 -72 04 51" if need turn "*" string add 
        /// </summary>
        /// for DEC?
        /// <returns></returns>
        public static string Deg2String(double deg)
        {

            string res = "";

            double d = deg;//  
                           //   d = Map360(deg);

            int dd = (int)(d);
            d -= dd;
            d *= 60.0;
            int dm = (int)(d);
            d -= dm;
            d *= 60.0;
            int ds = (int)(d + 0.5);
            res += deg < 0 ? '-' : '+';
            res += string.Format(@"{0:00} {1:00} {2:00}", dd, dm, ds);
            return res;
        }

        //for RA?
        public static string Deg2HString(double deg)
        {
            string res = "";
            double a = Map24(deg / 15);//  / 15.0;
            int h = (int)(a);
            a -= h;
            a *= 60.0;
            int m = (int)(a);
            a -= m;
            a *= 60.0;
            int s = (int)(a);
            a -= s;
            a *= 100;

            res = string.Format(@"{0:00} {1:00} {2:00}.{3:00} ", h, m, s, (int)a);

            return res;
        }
    }

    /// <summary>
    /// need Cel lib
    /// </summary>
    public class PointCel
    {
        private double ra, dec;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="raHour">double 24h format</param>
        /// <param name="decDegree">double 360deg format</param>
        public PointCel(double raHour, double decDegree)
        {
            ra = Cel.Map24(raHour);
            dec = Cel.Map360(decDegree);
        }

        /// <summary>
        /// Ra Dec String "HH MM SS.dd +DD mm ss" to PointCel
        /// </summary>
        /// <param name="str">"00 24 05.2 -72 04 51"  </param>
        /// <param name="ra"> hour format 0-23.9999</param>
        /// <param name="dec">degree format 0-359.999</param>
        /// <returns></returns>
        public PointCel(string str)
        {
            //transrate 
            double rh = 0;
            double de = 0;
            if (Cel.RaDecStringToEquatorial(str, ref rh, ref de))
            {//success
                /*
                double altitude2, azimuth2;
                double ha = ra * 15 * Math.PI / 180.0;
                double phi = latitude * Math.PI / 180.0;
                double dec = de * Math.PI / 180.0;

                altitude2 = Math.Asin(Math.Sin(phi) * Math.Sin(dec) + Math.Cos(phi) * Math.Cos(dec) * Math.Cos(ha));
                altitude2 = altitude2 * 180.0 / Math.PI;
                azimuth2 = Math.Atan2(-Math.Cos(dec) * Math.Sin(ha),
                                Math.Sin(dec) * Math.Cos(phi) - Math.Sin(phi) * Math.Cos(dec) * Math.Cos(ha));
                azimuth2 = azimuth2 * 180.0 / Math.PI;
                azimuth2 = Map360(azimuth2);

                if (altitude2 > 0)
                {
                    textRaDec.BackColor = Color.White;
                }
                else
                    textRaDec.BackColor = Color.Gray;
                twTarRA.Value = (int)(ra * 3600);
                twTarDec.Value = (int)(de * 3600);
                */
            }
            else
            {
                //Need Throw ?? 
                throw new ArgumentException(
                   "あかん。", "ra dec");
            }
            ra = Cel.Map24(rh);
            dec = Cel.Map360(de);

        }

        public bool Equal(PointCel dst)
        {
            if (Math.Abs(Cel.Map24(ra - dst.Ra)) > 0.000003) return false;
            if (Math.Abs(Cel.Map360(dec - dst.Dec)) > 0.00003) return false;
            return true;
        }

        /// <summary>
        /// Set couple data 
        /// </summary>
        /// <param name="_ra"></param>
        /// <param name="_de"></param>
        public void Set(double _ra, double _de)
        {
            ra = _ra;
            dec = _de;
        }
        public void Set(PointCel pt)
        {
            ra = pt.ra;
            dec = pt.dec;
        }

        /// <summary>
        /// Right Ascension in HourFormat
        /// 0.0000 ... 23.9999
        /// </summary>
        public double Ra
        {
            get
            {
                return ra;
            }
            set
            {
                if (ra != value)
                {
                    ra = Cel.Map24(value);
                }
            }
        }
        /// <summary>
        /// Declination  in degree Format
        /// 0.0000 ... 359.9999
        /// </summary>
        public double Dec
        {
            get
            {
                return dec;
            }
            set
            {
                if (dec != value)
                {
                    dec = Cel.Map360(value);
                }
            }
        }

        public double RaDeg
        {
            get
            {
                return ra * 15.0;
            }
            set
            {
                if (ra * 15.0 != value)
                {
                    ra = Cel.Map24(value / 15.0);
                }
            }
        }

        /// <summary>
        /// Same as Dec  Declination  in degree Format
        /// </summary>
        public double DecDeg
        {
            get
            {
                return dec;
            }
            set
            {
                if (dec != value)
                {
                    dec = Cel.Map360(value);
                }
            }
        }

        /// <summary>
        /// "00 24 05.2 -72 04 51" if need turn "*" string add 
        /// </summary>
        /// <returns></returns>
        new public string ToString()
        {
            bool turn = false;
            bool minus = false;
            string res = "";

            double d;//  / 15.0;
            if (dec > 180) d = dec - 360;
            else d = dec;

            if (d < 0)
            {
                d = -d;
                minus = true;
            }
            if (d > 90)
            {
                d = 180 - d;
                turn = true;
            }

            int dd = (int)(d);
            d -= dd;
            d *= 60.0;
            int dm = (int)(d);
            d -= dm;
            d *= 60.0;
            int ds = (int)(d + 0.5);

            double a = ra;//  / 15.0;
            if (turn)
            {
                a += 12.0;
                if (a > 24.0) a -= 24.0;
            }
            int h = (int)(a);
            a -= h;
            a *= 60.0;
            int m = (int)(a);
            a -= m;
            a *= 60.0;
            int s = (int)(a);
            a -= s;
            a *= 100;

            res = string.Format(@"{0:00} {1:00} {2:00}.{3:00} ", h, m, s, (int)a);
            res += minus ? '-' : '+';
            res += string.Format(@"{0:00} {1:00} {2:00}", dd, dm, ds);
            if (turn) res += " *";

            return res;
        }

    }


    /// <summary>
    /// HSV (HSB) カラーを表す
    /// </summary>
    public class HsvColor
    {
        private float _h;
        /// <summary>
        /// 色相 (Hue)
        /// </summary>
        public float H
        {
            get { return this._h; }
        }

        private float _s;
        /// <summary>
        /// 彩度 (Saturation)
        /// </summary>
        public float S
        {
            get { return this._s; }
        }

        private float _v;
        /// <summary>
        /// 明度 (Value, Brightness)
        /// </summary>
        public float V
        {
            get { return this._v; }
            set { this._v = value; }
        }

        private HsvColor(float hue, float saturation, float brightness)
        {
            if (hue < 0f || 360f <= hue)
            {
                throw new ArgumentException(
                    "hueは0以上360未満の値です。", "hue");
            }
            if (saturation < 0f || 1f < saturation)
            {
                throw new ArgumentException(
                    "saturationは0以上1以下の値です。", "saturation");
            }
            if (brightness < 0f || 1f < brightness)
            {
                throw new ArgumentException(
                    "brightnessは0以上1以下の値です。", "brightness");
            }

            this._h = hue;
            this._s = saturation;
            this._v = brightness;
        }

        /// <summary>
        /// 指定したColorからHsvColorを作成する
        /// </summary>
        /// <param name="rgb">Color</param>
        /// <returns>HsvColor</returns>
        public static HsvColor FromRgb(Color rgb)
        {
            float r = (float)rgb.R / 255f;
            float g = (float)rgb.G / 255f;
            float b = (float)rgb.B / 255f;

            float max = Math.Max(r, Math.Max(g, b));
            float min = Math.Min(r, Math.Min(g, b));

            float brightness = max;

            float hue, saturation;
            if (max == min)
            {
                //undefined
                hue = 0f;
                saturation = 0f;
            }
            else
            {
                float c = max - min;

                if (max == r)
                {
                    hue = (g - b) / c;
                }
                else if (max == g)
                {
                    hue = (b - r) / c + 2f;
                }
                else
                {
                    hue = (r - g) / c + 4f;
                }
                hue *= 60f;
                if (hue < 0f)
                {
                    hue += 360f;
                }

                saturation = c / max;
            }

            return new HsvColor(hue, saturation, brightness);
        }

        /// <summary>
        /// 指定したHsvColorからColorを作成する
        /// </summary>
        /// <param name="hsv">HsvColor</param>
        /// <returns>Color</returns>
        public static Color ToRgb(HsvColor hsv)
        {
            float v = hsv.V;
            float s = hsv.S;

            float r, g, b;
            if (s == 0)
            {
                r = v;
                g = v;
                b = v;
            }
            else
            {
                float h = hsv.H / 60f;
                int i = (int)Math.Floor(h);
                float f = h - i;
                float p = v * (1f - s);
                float q;
                if (i % 2 == 0)
                {
                    //t
                    q = v * (1f - (1f - f) * s);
                }
                else
                {
                    q = v * (1f - f * s);
                }

                switch (i)
                {
                    case 0:
                        r = v;
                        g = q;
                        b = p;
                        break;
                    case 1:
                        r = q;
                        g = v;
                        b = p;
                        break;
                    case 2:
                        r = p;
                        g = v;
                        b = q;
                        break;
                    case 3:
                        r = p;
                        g = q;
                        b = v;
                        break;
                    case 4:
                        r = q;
                        g = p;
                        b = v;
                        break;
                    case 5:
                        r = v;
                        g = p;
                        b = q;
                        break;
                    default:
                        throw new ArgumentException(
                            "色相の値が不正です。", "hsv");
                }
            }

            return Color.FromArgb(
                (int)Math.Round(r * 255f),
                (int)Math.Round(g * 255f),
                (int)Math.Round(b * 255f));
        }

        public static Color cvt(Color c, float mag, float gloss = 0.0f)
        {
            HsvColor hsv = HsvColor.FromRgb(c);
            float b = hsv.V;

            if (mag > -0.5 && mag < 0.5)
            {
                b += mag;
                if (b > 1f) b = 1f;
                if (b < 0) b = 0f;
            }
            else if (mag == 0.5f)
            {
                if (b > 1f) b -= 1f;
                if (b < 0) b += 1f;
            }

            else b = mag;

            b += gloss;
            if (b > 1.0f) b = 1f;
            if (b < 0.0f) b = 0f;
            hsv.V = b;
            return HsvColor.ToRgb(hsv);
        }

    }



    public class Reg
    {
        public static void ReadAllSettings()
        {
            try
            {
                var appSettings = ConfigurationManager.AppSettings;

                if (appSettings.Count == 0)
                {
                    Debug.WriteLine("AppSettings is empty.");
                }
                else
                {
                    foreach (var key in appSettings.AllKeys)
                    {
                        Debug.WriteLine("Key: {0} Value: {1}", key, appSettings[key]);
                    }
                }
            }
            catch (ConfigurationErrorsException)
            {
                Debug.WriteLine("Error reading app settings");
            }
        }

        public static string ReadSetting(string key)
        {
            try
            {
                var appSettings = ConfigurationManager.AppSettings;
                string result = appSettings[key] ?? "Not Found";
                Debug.WriteLine(result);
                return result;
            }
            catch (ConfigurationErrorsException)
            {
                Debug.WriteLine("Error reading app settings");
            }
            return "";
        }

        public static void AddUpdateAppSettings(string key, string value)
        {
            try
            {
                var configFile = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                var settings = configFile.AppSettings.Settings;
                if (settings[key] == null)
                {
                    settings.Add(key, value);
                }
                else
                {
                    settings[key].Value = value;
                }
                configFile.Save(ConfigurationSaveMode.Modified);
                ConfigurationManager.RefreshSection(configFile.AppSettings.SectionInformation.Name);
            }
            catch (ConfigurationErrorsException)
            {
                Debug.WriteLine("Error writing app settings");
            }
        }





    }
}
