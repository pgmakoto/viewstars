﻿namespace bsc5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            button1 = new Button();
            folderBrowserDialog1 = new FolderBrowserDialog();
            ucSwitch1 = new ucPgmac.ucSwitch();
            hScrollBar1 = new HScrollBar();
            tenqu1 = new Tenqu();
            label1 = new Label();
            ucSwitch2 = new ucPgmac.ucSwitch();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox1.Location = new Point(12, 12);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(569, 23);
            textBox1.TabIndex = 0;
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            button1.Location = new Point(587, 12);
            button1.Name = "button1";
            button1.Size = new Size(60, 26);
            button1.TabIndex = 1;
            button1.Text = "folder";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // ucSwitch1
            // 
            ucSwitch1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            ucSwitch1.Checked = true;
            ucSwitch1.ColorOff = Color.MidnightBlue;
            ucSwitch1.ColorOn = Color.SlateBlue;
            ucSwitch1.Location = new Point(587, 44);
            ucSwitch1.Name = "ucSwitch1";
            ucSwitch1.Size = new Size(57, 24);
            ucSwitch1.TabIndex = 0;
            ucSwitch1.CheckedChanged += ucSwitch1_CheckedChanged;
            // 
            // hScrollBar1
            // 
            hScrollBar1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            hScrollBar1.LargeChange = 100;
            hScrollBar1.Location = new Point(11, 44);
            hScrollBar1.Maximum = 1200;
            hScrollBar1.Minimum = -1200;
            hScrollBar1.Name = "hScrollBar1";
            hScrollBar1.Size = new Size(462, 16);
            hScrollBar1.TabIndex = 3;
            hScrollBar1.Scroll += hScrollBar1_Scroll;
            // 
            // tenqu1
            // 
            tenqu1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tenqu1.AutoScroll = true;
            tenqu1.BackColor = Color.MidnightBlue;
            tenqu1.cel = null;
            tenqu1.Location = new Point(2, 74);
            tenqu1.Move = false;
            tenqu1.Name = "tenqu1";
            tenqu1.Size = new Size(653, 401);
            tenqu1.stars = null;
            tenqu1.TabIndex = 4;
            tenqu1.Load += tenqu1_Load;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.Gold;
            label1.Location = new Point(483, 45);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 5;
            label1.Text = "label1";
            // 
            // ucSwitch2
            // 
            ucSwitch2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            ucSwitch2.Checked = true;
            ucSwitch2.ColorOff = Color.MidnightBlue;
            ucSwitch2.ColorOn = Color.SlateBlue;
            ucSwitch2.Location = new Point(524, 44);
            ucSwitch2.Name = "ucSwitch2";
            ucSwitch2.Size = new Size(57, 24);
            ucSwitch2.TabIndex = 6;
            ucSwitch2.CheckedChanged += ucSwitch2_CheckedChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkSlateBlue;
            ClientSize = new Size(659, 476);
            Controls.Add(ucSwitch2);
            Controls.Add(label1);
            Controls.Add(tenqu1);
            Controls.Add(hScrollBar1);
            Controls.Add(ucSwitch1);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Button button1;
        private FolderBrowserDialog folderBrowserDialog1;
        private ucPgmac.ucSwitch ucSwitch1;
        private HScrollBar hScrollBar1;
        private Tenqu tenqu1;
        private Label label1;
        private ucPgmac.ucSwitch ucSwitch2;
    }
}
