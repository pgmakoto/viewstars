﻿using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Formats.Tar;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using ucPgmac;


namespace bsc5
{

    //http://tdc-www.harvard.edu/catalogs/catalogsb.html
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct st_hipheaderinfo
    {
        public readonly Int32 NBENT;//スターエントリあたりのバイト数
        public readonly Int32 nmag;// 存在する等級の数(0-10) 負の場合、座標はB1950ではなくJ2000になります。
        public readonly Int32 mprop;// 固有運動が含まれていない場合は0  1 固有運動が含まれる場合 視線速度が含まれる場合は2
        public readonly Int32 stnum; //星ID番号が存在しない場合は0
                           // 星のID番号がカタログファイルにある場合は1
                           // 星のID番号が地域nnnn（GSC）の場合は2
                           // 星のID番号が領域nnnnn（ティコ）の場合は3
		                   // 4 星のID番号が整数*4 で実数*4 でない場合
                           // <0 ID番号はありませんが、オブジェクト名は-STNUM文字です
                           // エントリー終了時
        public readonly Int32 count;  //ファイル内の星の数     負の場合、座標はB1950ではなくJ2000になります。
        public readonly Int32 firstnum;  //ファイル内の最初の星の番号
        public readonly Int32 num;  //スター番号から減算してシーケンス番号を取得します
    };

   
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct st_hipinfo
    {
        public Int32 XNO;      //XNO 星のカタログ番号[オプション]
        public double SRAD;    // SRA0 B1950 赤経（ラジアン）
        public double SDECO;   //SDEC0 B1950 偏角（ラジアン）
        public char ISP0;      //ISPスペクトル型（2文字）
        public char ISP1;      //
        public Int16 MAG100;   //V 大きさ * 100 [0-10 が存在する可能性があります]
        public Single XRPM_RA;  //XRPM RA 固有運動(ラジアン/年) [オプション]
        public Single XDPM_Dec; //XDPM Dec.固有運動(ラジアン/年) [オプション]
        public double SVEL;    //SVEL 視線速度（キロメートル/秒）（オプション）
        /*  
        public readonly char b6;      //
        public readonly char b5;      //ISPスペクトル型（2文字）
        public readonly char b4;      //
        public readonly char b3;      //ISPスペクトル型（2文字）
        public readonly char b2;      //
        public readonly char b1;      //ISPスペクトル型（2文字）
        */
    };

    /*
    スペクトル型 O5  B5        A5       F5      G5      K5      M5
    恒星の色 青      青白      白       黄白    黄      橙      赤
    表面温度 45000K  15000K    8300K	6600K	5600K	4400K	3300K
    */

    public class HipStar
    {
        private FolderBrowserDialog folderBrowserDialog1;
        private string filepath = "";

        public st_hipheaderinfo fil = new st_hipheaderinfo();
        public List<Star> stars
        {
            get; set;
        }// = new List<Star>();

        static st_hipheaderinfo BytesToSt_hipheaderinfo(byte[] bytes)
        {
            var gch = GCHandle.Alloc(bytes, GCHandleType.Pinned);                            // step1
            var result = (st_hipheaderinfo)Marshal.PtrToStructure(gch.AddrOfPinnedObject(), typeof(st_hipheaderinfo)); // step2
            gch.Free();                                                                      // step3
            return result;
        }
        //      static st_hipinfo BytesToSt_hipinfo(byte[] bytes)
        //      {
        //          var gch = GCHandle.Alloc(bytes, GCHandleType.Pinned);                            // step1
        //          var result = (st_hipinfo)Marshal.PtrToStructure(gch.AddrOfPinnedObject(), typeof(st_hipinfo)); // step2
        //          gch.Free();                                                                      // step3
        //          return result;
        //      }

        public static unsafe short ToInt16(byte[] value, int startIndex)
        {
            //   / *～エラーチェックとかのコード、省略～* /
            fixed (byte* pbyte = &value[startIndex])
            {
                {
                    return (short)((*pbyte << 8) | (*(pbyte + 1)));
                }
            }
        }

        public static unsafe Int32 ToInt32(byte[] value, int startIndex)
        {
            //   / *～エラーチェックとかのコード、省略～* /
            fixed (byte* pbyte = &value[startIndex])
            {
                {
                    return (Int32)((*pbyte << 24) | (*(pbyte + 1) << 16) | (*(pbyte + 2) << 8) | (*(pbyte + 3)));
                }
            }
        }
        public static unsafe double ToDouble(byte[] value, int startIndex)
        {
            //   / *～エラーチェックとかのコード、省略～* /
            byte[] sub = GetSubArray(value, startIndex, sizeof(double));
            return BitConverter.ToDouble(Reverse(sub), 0);
        }
        private static byte[] GetSubArray(byte[] src, int startIndex, int count)
        {
            byte[] dst = new byte[count];
            Array.Copy(src, startIndex, dst, 0, count);
            return dst;
        }
        private static byte[] Reverse(byte[] bytes)
        {
            return bytes.Reverse().ToArray();
        }
        public static unsafe float ToSingle(byte[] value, int startIndex)
        {
            byte[] sub = GetSubArray(value, startIndex, sizeof(float));
            return BitConverter.ToSingle(Reverse(sub), 0);
        }
        /**/
        public void doset()
        {
            folderBrowserDialog1 = new FolderBrowserDialog();

            if (filepath == "") folderBrowserDialog1.InitialDirectory = AppContext.BaseDirectory;
            if (DialogResult.OK == folderBrowserDialog1.ShowDialog())
            {
                filepath = folderBrowserDialog1.SelectedPath ;
                Reg.AddUpdateAppSettings("HipPath", filepath);
            }
        }

        public HipStar( List<Star> st)
        {
            stars = st;
            filepath = Reg.ReadSetting("HipPath") ;
            string datafile = filepath + @"\hipparcos";
            if (File.Exists(datafile))
            {
                // filePathのファイルは存在する
                using (var reader = new BinaryReader(new FileStream(datafile, FileMode.Open)))
                {
                    // https://zenn.dev/flipflap/articles/a72a3fc40605f7
                    //byte[] hdr = new byte[28];
                    Span<byte> hdr = stackalloc byte[Unsafe.SizeOf<st_hipheaderinfo>()];
                    reader.Read(hdr);
                    hdr.Reverse();
                    var fil = MemoryMarshal.AsRef<st_hipheaderinfo>(hdr) ;
                    int size = fil.NBENT;
                    byte[] buffer = new byte[size];
                    //https://qiita.com/kob58im/items/99b45df5bc2d75ccf58a
                    int ent = 0;
                    while (ent<120000) {
                        try
                        {
                            Byte[] buff = new Byte[size];
                            reader.Read(buff);

                            st_hipinfo hip = new st_hipinfo();
                            int p = 0;
                           // hip.XNO = (Int32)(buff[p] | (buff[p + 1] << 8) | (buff[p + 2] << 16) | (buff[p + 3] << 24));
                            hip.XNO = (Int32)((buff[p] << 24) | (buff[p + 1] << 16  | (buff[p + 2]<< 8)) | (buff[p + 3]));
                            p += 4;
                            hip.SRAD = ToDouble(buff, p);
                            p += 8;
                            hip.SDECO = ToDouble(buff, p);
                            p += 8;
                            hip.ISP0 = (char)buff[p]; p++;
                            hip.ISP1 = (char)buff[p]; p++;
                            hip.MAG100 = ToInt16(buff, p);
                            p += 2;
                            hip.XRPM_RA = ToSingle(buff, p);
                            p += 4;
                            hip.XDPM_Dec = ToSingle(buff, p);
                            p += 4;
                            hip.SVEL = (Int16)(buff[0]<< 8 | (buff[1] ));

                            /*
                            hip.SRAD = (double)(buff[p] | (buff[p + 1] << 8) | (buff[p + 2] << 16) | (buff[p + 3] << 24) | (buff[p + 4] << 32) | (buff[p + 5] << 40) | (buff[p + 6] << 48) | (buff[p + 7] << 56));
                            p += 8;
                            hip.SDECO = (double)(buff[p] | (buff[p + 1] << 8) | (buff[p + 2] << 16) | (buff[p + 3] << 24) | (buff[p + 4] << 32) | (buff[p + 5] << 40) | (buff[p + 6] << 48) | (buff[p + 7] << 56));
                            p += 8;
                            hip.ISP0 = (char)buff[p]; p++;
                            hip.ISP1 = (char)buff[p]; p++;
                            hip.MAG100 = (Int16)(buff[0] | (buff[1] << 8));
                            p += 2;
                            hip.XRPM_RA = (float)(buff[p] | (buff[p + 1] << 8) | (buff[p + 2] << 16) | (buff[p + 3] << 24));
                            p += 4;
                            hip.XDPM_Dec = (float)(buff[p] | (buff[p + 1] << 8) | (buff[p + 2] << 16) | (buff[p + 3] << 24));
                            p += 4;
                            hip.SVEL = (Int16)(buff[0] | (buff[1] << 8));
                            */
                            Star particle = new Star(hip);
                            stars.Add(particle);
                        }
                        catch(ArgumentOutOfRangeException ex)
                        {
                            Console.WriteLine(" error : " + ent.ToString());
                            break;
                        }
                        ent++;
                    }
                }

        //        // ファイルを開く＆文字化け防止
        //        // コードページ エンコーディング プロバイダーを登録
        //        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        //        using (StreamReader file = new StreamReader(datafile, Encoding.GetEncoding("shift-jis")))
        //        {
        //            // 行末まで１行ずつ読み込む
        //            while (file.Peek() != -1)
        //            {
        //                string line = file.ReadLine();
        //                if (line != null)
        //                {
        //                    Star particle = new Star(line);
        //                    stars.Add(particle);
        //                    Console.WriteLine(line);
        //                }
        //            }
        //        }

            }

        }


    }
}
